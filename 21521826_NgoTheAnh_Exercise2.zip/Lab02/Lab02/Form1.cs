﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02
{
    public partial class Form1 : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=MYPC\\MSSQLSERVER01;Initial Catalog=STUDENTMANAGEMENT;Integrated Security=True";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "Select * from STUDENT ";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dgv.DataSource = table;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            loaddata();
        }

        private void bt_ketnoi_Click(object sender, EventArgs e)
        {
            string connectionString = bt_ketnoi.Text;
            connection = new SqlConnection(connectionString);

            try
            {
                connection.Open();
                MessageBox.Show("Kết nối CSDL thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối CSDL: " + ex.Message);
            }
        }

        private void bt_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "insert into STUDENT values('" + tb_id.Text + "','" + tb_name.Text + "', '" + dtime_birth.Text + "', '" + tb_address.Text + "')";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_id.ReadOnly = true;
            int i;
            i = dgv.CurrentRow.Index;
            tb_id.Text = dgv.Rows[i].Cells[0].Value.ToString();
            tb_name.Text = dgv.Rows[i].Cells[1].Value.ToString();
            dtime_birth.Text = dgv.Rows[i].Cells[2].Value.ToString();
            tb_address.Text = dgv.Rows[i].Cells[3].Value.ToString();
        }

        private void dt_birth_ValueChanged(object sender, EventArgs e)
        {

        }

        private void bt_xoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "delete from STUDENT where ID= '" + tb_id.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
        }

        private void bt_truyvan_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "update STUDENT set name = '" + tb_name.Text + "', birth = '" + dtime_birth.Text + "', address = '" + tb_address.Text + "' where id = '" + tb_id.Text + "'";
            command.ExecuteNonQuery();
            loaddata();
        }
    }
}
