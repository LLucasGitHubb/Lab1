﻿namespace Lab02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtime_birth = new System.Windows.Forms.DateTimePicker();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_ketnoi = new System.Windows.Forms.Button();
            this.bt_them = new System.Windows.Forms.Button();
            this.bt_truyvan = new System.Windows.Forms.Button();
            this.bt_xoa = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgv);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1037, 315);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông Tin";
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(3, 18);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 51;
            this.dgv.RowTemplate.Height = 24;
            this.dgv.Size = new System.Drawing.Size(1028, 291);
            this.dgv.TabIndex = 0;
            this.dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtime_birth);
            this.groupBox2.Controls.Add(this.tb_address);
            this.groupBox2.Controls.Add(this.tb_name);
            this.groupBox2.Controls.Add(this.tb_id);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 348);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(573, 190);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // dtime_birth
            // 
            this.dtime_birth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtime_birth.Location = new System.Drawing.Point(85, 116);
            this.dtime_birth.Name = "dtime_birth";
            this.dtime_birth.Size = new System.Drawing.Size(111, 22);
            this.dtime_birth.TabIndex = 7;
            // 
            // tb_address
            // 
            this.tb_address.Location = new System.Drawing.Point(83, 155);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(114, 22);
            this.tb_address.TabIndex = 6;
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(83, 73);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(114, 22);
            this.tb_name.TabIndex = 5;
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(83, 30);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(114, 22);
            this.tb_id.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "address ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "birth";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "id ";
            // 
            // bt_ketnoi
            // 
            this.bt_ketnoi.Location = new System.Drawing.Point(666, 348);
            this.bt_ketnoi.Name = "bt_ketnoi";
            this.bt_ketnoi.Size = new System.Drawing.Size(134, 52);
            this.bt_ketnoi.TabIndex = 2;
            this.bt_ketnoi.Text = "Kết Nối";
            this.bt_ketnoi.UseVisualStyleBackColor = true;
            this.bt_ketnoi.Click += new System.EventHandler(this.bt_ketnoi_Click);
            // 
            // bt_them
            // 
            this.bt_them.Location = new System.Drawing.Point(666, 486);
            this.bt_them.Name = "bt_them";
            this.bt_them.Size = new System.Drawing.Size(134, 52);
            this.bt_them.TabIndex = 3;
            this.bt_them.Text = "Thêm";
            this.bt_them.UseVisualStyleBackColor = true;
            this.bt_them.Click += new System.EventHandler(this.bt_them_Click);
            // 
            // bt_truyvan
            // 
            this.bt_truyvan.Location = new System.Drawing.Point(855, 348);
            this.bt_truyvan.Name = "bt_truyvan";
            this.bt_truyvan.Size = new System.Drawing.Size(136, 52);
            this.bt_truyvan.TabIndex = 4;
            this.bt_truyvan.Text = "Truy Vấn";
            this.bt_truyvan.UseVisualStyleBackColor = true;
            this.bt_truyvan.Click += new System.EventHandler(this.bt_truyvan_Click);
            // 
            // bt_xoa
            // 
            this.bt_xoa.Location = new System.Drawing.Point(855, 486);
            this.bt_xoa.Name = "bt_xoa";
            this.bt_xoa.Size = new System.Drawing.Size(136, 52);
            this.bt_xoa.TabIndex = 5;
            this.bt_xoa.Text = "Xóa";
            this.bt_xoa.UseVisualStyleBackColor = true;
            this.bt_xoa.Click += new System.EventHandler(this.bt_xoa_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 561);
            this.Controls.Add(this.bt_xoa);
            this.Controls.Add(this.bt_truyvan);
            this.Controls.Add(this.bt_them);
            this.Controls.Add(this.bt_ketnoi);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_ketnoi;
        private System.Windows.Forms.Button bt_them;
        private System.Windows.Forms.Button bt_truyvan;
        private System.Windows.Forms.Button bt_xoa;
        private System.Windows.Forms.DateTimePicker dtime_birth;
    }
}

